# Kardex — Pantalla de registro (RF-01)

Código inicial del proyecto Flutter de Kardex, empezando por el
registro de usuario según el mockup y la especificación de
requerimientos (RF-01, RF-24).

## Qué incluye esta primera entrega

- `lib/core/validators.dart` — validaciones de todos los campos
  (nombre, correo, contraseña, confirmación, teléfono, texto libre con
  máximo de caracteres, tipo de sangre), siguiendo RF-01 y RF-24.
- `lib/models/app_user.dart` — modelos `UserRole`, `RegisterData`,
  `MedicalProfile`, `EmergencyContact`, `AppUser`.
- `lib/services/auth_service.dart` — contrato `AuthService` +
  `MockAuthService` (funciona sin backend, simula "correo ya
  registrado") + plantilla comentada de la implementación real con
  Firebase.
- `lib/screens/register_screen.dart` — pantalla de registro completa:
  nombre, correo, contraseña + confirmación, teléfono, selector de rol
  y, si el rol es Paciente, la sección "Información médica" (tipo de
  sangre, hasta 2 alergias, hasta 2 condiciones, contacto de
  emergencia).
- `lib/main.dart` — arranca la app directamente en la pantalla de
  registro, usando `MockAuthService` para poder probarla ya mismo.

## Cómo correrlo

Este proyecto se entregó solo con el código fuente (`lib/` y
`pubspec.yaml`), sin las carpetas `android/` e `ios/` que genera
Flutter automáticamente. Para ejecutarlo:

```bash
# 1. Crea el esqueleto de un proyecto Flutter nuevo
flutter create kardex_tmp

# 2. Copia dentro de él el pubspec.yaml y la carpeta lib/ de este repo
#    (sobrescribiendo los que trae por defecto)

# 3. Instala dependencias
cd kardex_tmp
flutter pub get

# 4. Corre la app (emulador o dispositivo conectado)
flutter run
```

Cuando confirmes que corre bien, puedes renombrar `kardex_tmp` como
prefieras o mover su contenido a este repo.

## Siguiente paso: conectar Firebase (opcional por ahora)

La pantalla ya funciona con `MockAuthService`, así que no necesitas
Firebase para probar el formulario y sus validaciones. Cuando quieras
conectar el backend real:

1. Ejecuta `flutterfire configure` para generar `firebase_options.dart`.
2. Inicializa Firebase en `main()`.
3. Descomenta y ajusta `FirebaseAuthService` en
   `lib/services/auth_service.dart`.
4. Reemplaza `MockAuthService()` por `FirebaseAuthService()` en
   `lib/main.dart`.

## Requerimientos cubiertos

- **RF-01** — Registro de usuario (cuenta + perfil médico inicial si el
  rol es Paciente).
- **RF-24** (parcial) — Validación de tipo de dato por campo: correo,
  contraseña (oculta, con `obscureText`), numérico (teléfono) y texto
  libre con límite de caracteres.

Pendientes para una próxima entrega: RF-02 (login), RF-03
(navegación por rol), RF-19 (recuperar contraseña), y el resto de
RF-24 para las demás pantallas.
